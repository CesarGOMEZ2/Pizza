package com.upchiapas;
import models.Revanada;

public class Main {
    public static void main(String[] args) {

        Revanada switcher = new Revanada();
        switcher.MainMenu();
    }
}